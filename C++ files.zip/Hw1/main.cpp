#include <iostream>
using namespace std;
int average(int a[]){
    int sum=0;
    for(int i=0;i<10;i++)
        sum+=a[i];
    return sum/10;
}
int main() {
    int b[10]
    int n=0,
    int k=0;
    for(int i=0;i<10;i++)
        cin>>b[i];
    for(int i=0;i<10;i++){
        if(a[i]<average(a))
            n++;
        else
            k++;
    }
    cout<<"Number of scores above or equal to the average is "<<k<<". "<<"Number of scores below the average is "<<n<<endl;
    return 0;
}