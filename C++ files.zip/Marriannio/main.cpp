#include <iostream>
using namespace std;

    void invert(int *arr, int n) {
        int y;
        for (int i = 0; i < n / 2; i++) {

            y = *(arr + i);
            *(arr + i) = *(arr+n -1 - i);
            *(arr+n -1- i) = y;
        }
    }
    int main() {
        int n;
        cin >> n;
        int *arr = new int[n];
        for (int i = 0; i < n; i++) {
            cin >> *(arr + i);
        }
        invert(arr,n);
        for (int j = 0; j < n; ++j) {
            cout<<*(arr+j)<<" ";
        }
    }

