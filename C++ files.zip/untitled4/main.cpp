#include <iostream>
using namespace std;
int x,y;
void mami(int& x, int& y){
    int a[5]={1,2,3,4,5};
    y=a[0];
    for(int i=0;i<5;i++){
        if(a[i]>x)
            x=a[i];
        else
            if(a[i]<y)
                y=a[i];
    }

}
void power(int& b){
   b*=b;
}
int iplusplus (int& n) {
    int a = n;
    n =n+1;
    return a;
}
int plusplus (int& n) {
    n = n + 1;
    return n;
}
int main() {
    int a[10]={1,2,3,4,5,6,7,8,9,10};
    for(int i=0;i<10;i++){
        power(a[i]);
        cout<<a[i]<<" ";
    }
    cout<<endl;
    int j=4,h=4;
    cout<<iplusplus(h)<<endl<< plusplus(j)<<endl;

    mami(x,y);
    cout<<x<<endl<<y<<endl;
    return 0;
}