#include<iostream>
using namespace std;
int main(){
    int n;
    int a[10];
    for(int i=1;i<=10;i++)
        a[i]=i;
    int b[10];
    for(int i=1;i<=10;i++)
        b[i]=0;
    while(true){
        cin>>n;
        if(n<1 ||n>10 )
            break;
        for(int i=1;i<=10;i++){
            if(n==a[i])
                b[i]++;
        }

    }
    for(int i=1;i<=10;i++){
        cout<<"Number "<<i<<" appears "<<b[i]<<" times"<<endl;
    }
    return 0;
}

