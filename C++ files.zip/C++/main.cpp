//// group work with Hrayr Azaryan
#include <iostream>
using namespace std;
void bublesortArray(int* array, int n)
{

    int temp ;


        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (*(array+i) > *(array+j)) {
                    temp = *(array+i);

                    *(array+i) = *(array+j);

                    *(array+j) = temp;
                }
            }
        }
}
bool chek(int* array,int n)
{
	int k=0;
    for (int j = 0; j <n/2 ; ++j) {
        if(*(array+j)==*(array+(n-1-j))){
            k++;
        }

    }
    if(k==n/2)
        return true;
    else
        return false;

}
int main() {
    int n;
    cin>>n;
    int* arr = new int[n];
   for (int i = 0; i < n; ++i) {
        cin>>*(arr+i);
    }
    if(chek(arr,n))
    	cout<<"Symetric"<<endl;
    else
    	cout<<"Not Symetric"<<endl;

    bublesortArray(arr,n);
    for (int l = 0; l < n; ++l) {
        cout<<*(arr+l)<<" ";
    }
    cout<<endl;
    return 0;
}

