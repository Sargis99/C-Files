#include <iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int a[n][n];
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            cin>>a[i][j];
    int sum=0,sum1=0;
    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++) {
            sum += a[i][j];
            sum1+= a[j][i];
        }
    cout<<sum<<endl<<sum1<<endl;
    return 0;
}