#include <iostream>
using namespace std;


int main()
{
  int n,m,y,x=0,k=0,q=1,p;
    cin>>n;
    int a[n][n];
    m=n; y=n;
    if(n%2==0)
        p=n/2;
    else
        p=n/2+1;
    while(k<p) {
        for (int i = k; i < m; ++i) {
            a[x][i] = q;
            q++;
        }
        x++;
        for (int j = x; j < y; ++j) {
            a[j][m - 1] = q;
            q++;
        }
        m--;
        for (int l = m - 1; l >= k; --l) {
            a[y - 1][l] = q;
            q++;
        }
        y--;
        for (int i1 = y - 1; i1 >= x; --i1) {
            a[i1][k] = q;
            q++;
        }
        k++;
    }
    for (int j1 = 0; j1 < n; ++j1) {
        for (int i = 0; i <n ; ++i) {
            cout<<a[j1][i]<<" ";
        }
        cout<<endl;
    }
    return 0;
}
