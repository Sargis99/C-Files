#include <iostream>

int main() {
    
    int x,y;
    char z;
    std::cin>>x>>z>>y;
    switch(z){
        case '+':
        std::cout<<x+y<<std::endl;
            break;
        case '-':
        std::cout<<x-y<<std::endl;
            break;
        case '*':
        std::cout<<x*y<<std::endl;
            break;
        case '/':
        std::cout<<x/y<<std::endl;
            break;
        default:
            break;

    }
    return 0;
}