#include <iostream>
using namespace std;
void reverse(int* arr,int n){
    int result=0;
    int reminder=0;
    for(int i=0;i<n;i++){
        result=0;
        reminder=0;
        while(*(arr+i)>0){
        	reminder=*(arr+i)%10;
            result=result*10+reminder;
            *(arr+i)/=10;
        }
        *(arr+i)=result;
    }
}
int main()
{
    int n;
    cin>> n;
    int* arr = new int[n];
    for (int i = 0; i < n; ++i) {
        cin>>*(arr+i);
    }
    reverse(arr,n);
    for(int i=0;i<n;i++){
        cout<<*(arr+i)<<" ";
    }
}
