#include <iostream>
using namespace std;
int digit(int a){
    int d=0;
    while(a>0){
        a/=10;
        d++;
    }
    return d;
}
int main(){
    int a;
    cin>>a;
    cout<<digit(a)<<endl;
    return 0;
}