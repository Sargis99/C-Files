#include <iostream>
#include <Cmath>
using namespace std;
int prime(int a){
    int m,n=0;
    for(int i=2;i<=sqrt(a);i++){
        if(a%i==0)
            n++;
        else
            m=0;
    }
    if(n==m)
        return m;
    else
        return n;
}
int main() {
    int n;
    cin>>n;
    for(int i=n+1;;i++) {
        if (prime(i)==0) {
           nout<<"First prime number is "<<i<<endl;
            break;
        }
    }
    return 0;
}
