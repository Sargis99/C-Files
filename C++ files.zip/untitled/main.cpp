#include <iostream>
using namespace std;
int main(){
    int ma=0,mi=0,a[10],k,j;
    for(int i=0;i<10;i++)
        cin>>a[i];
    for(int i=0;i<10;i++){
        if(a[i]>ma){
            ma=a[i];
            k=i;
        }
    }
    mi=a[0];
    for(int i=0;i<10;i++){
        if(a[i]<mi){
            mi=a[i];
            j=i;
        }
    }
    a[j]=0;
    a[k]=0;
    for(int i=0;i<10;i++)
        cout<<a[i]<<" ";
    return 0;
}