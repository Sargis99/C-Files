#include <iostream>
using namespace std;
void Chnage(int* arr, int n)
{
    int y ;
    for(int j =n-1; j > 0; j--)
        for (int i = 0; i < j; i++){
            y = *(arr+i+1);
            *(arr+i+1) = *(arr+i);
            *(arr+i)= y;
        }

}
int main()
{
    int n;
    cin>>n;
    int* arr=new int[n];
    for (int i = 0; i < n; ++i) {
        cin>>*(arr+i);
    }
    Chnage(arr,n);
    for(int i=0;i<n;i++)
    {
        cout<<*(arr+i)<<" ";
    }
    return 0;
}